Site Pessoal como base para você criar o seu próprio. Funciona exatamente como um curriculum vitae para você editar.
